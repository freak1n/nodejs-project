Github repo на проекта: https://github.com/freak1n/nodejs-project
README.TXT - this референция
referatZadanie.docx - Самия реферат (за сега незавършен)
referat.html - html формат на реферата
